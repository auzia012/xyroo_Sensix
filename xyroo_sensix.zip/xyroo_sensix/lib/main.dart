import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';

void main() {
  runApp(const XyrooSensixApp());
}

class XyrooSensixApp extends StatelessWidget {
  const XyrooSensixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'XyrooSensix',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0A0F),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00F5FF),
          secondary: Color(0xFFFF006E),
          surface: Color(0xFF111118),
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

// ─── SPLASH SCREEN ────────────────────────────────────────────────────────────
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _fade = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.easeOut)));
    _scale = Tween<double>(begin: 0.7, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.elasticOut)));
    _ctrl.forward();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ShizukuSetupScreen()));
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: Center(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Opacity(
            opacity: _fade.value,
            child: Transform.scale(
              scale: _scale.value,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo
                  Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const SweepGradient(colors: [
                        Color(0xFF00F5FF),
                        Color(0xFFFF006E),
                        Color(0xFF7B2FFF),
                        Color(0xFF00F5FF),
                      ]),
                      boxShadow: [
                        BoxShadow(color: const Color(0xFF00F5FF).withOpacity(0.4), blurRadius: 30, spreadRadius: 5),
                      ],
                    ),
                    child: const Center(
                      child: Icon(Icons.settings_input_component_rounded, size: 52, color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text('XyrooSensix', style: TextStyle(
                    fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 2,
                    foreground: Paint()..shader = const LinearGradient(
                      colors: [Color(0xFF00F5FF), Color(0xFFFF006E)],
                    ).createShader(Rect.fromLTWH(0, 0, 220, 40)),
                  )),
                  const SizedBox(height: 8),
                  const Text('DPI & Sensitivity Controller', style: TextStyle(
                    color: Color(0xFF888899), fontSize: 13, letterSpacing: 1.5,
                  )),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: 160,
                    child: LinearProgressIndicator(
                      backgroundColor: const Color(0xFF1E1E2E),
                      valueColor: const AlwaysStoppedAnimation(Color(0xFF00F5FF)),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── SHIZUKU SETUP SCREEN ─────────────────────────────────────────────────────
class ShizukuSetupScreen extends StatefulWidget {
  const ShizukuSetupScreen({super.key});
  @override
  State<ShizukuSetupScreen> createState() => _ShizukuSetupScreenState();
}

class _ShizukuSetupScreenState extends State<ShizukuSetupScreen> {
  bool _shizukuConnected = false;

  void _connect() {
    setState(() => _shizukuConnected = true);
    Future.delayed(const Duration(milliseconds: 800), () {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              const Text('Setup', style: TextStyle(
                fontSize: 36, fontWeight: FontWeight.w900,
                color: Color(0xFF00F5FF), letterSpacing: 1,
              )),
              const Text('Privilege Required', style: TextStyle(
                fontSize: 15, color: Color(0xFF555566), letterSpacing: 1,
              )),
              const SizedBox(height: 48),
              _SetupCard(
                icon: Icons.security_rounded,
                title: 'Shizuku',
                subtitle: 'Required untuk menjalankan perintah sistem\n(wm density, wm size)',
                status: _shizukuConnected ? 'Connected' : 'Not Connected',
                statusColor: _shizukuConnected ? const Color(0xFF00FF88) : const Color(0xFFFF006E),
              ),
              const SizedBox(height: 20),
              _SetupCard(
                icon: Icons.layers_rounded,
                title: 'Overlay Permission',
                subtitle: 'Diperlukan untuk menampilkan floating window di atas aplikasi lain',
                status: 'Required',
                statusColor: const Color(0xFFFFAA00),
              ),
              const Spacer(),
              // Info box
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFF00F5FF).withOpacity(0.3)),
                  borderRadius: BorderRadius.circular(12),
                  color: const Color(0xFF00F5FF).withOpacity(0.05),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline_rounded, color: Color(0xFF00F5FF), size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Shizuku memungkinkan XyrooSensix mengubah DPI & resolusi layar tanpa root.',
                        style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12, height: 1.5),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _shizukuConnected ? null : _connect,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00F5FF),
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: Text(
                    _shizukuConnected ? 'Menghubungkan...' : 'Hubungkan Shizuku',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: 1),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: OutlinedButton(
                  onPressed: () => Navigator.pushReplacement(
                      context, MaterialPageRoute(builder: (_) => const MainScreen())),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFF333344)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('Lanjutkan Tanpa Shizuku',
                      style: TextStyle(color: Color(0xFF888899), fontSize: 13)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SetupCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, status;
  final Color statusColor;
  const _SetupCard({required this.icon, required this.title, required this.subtitle, required this.status, required this.statusColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF111118),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1E1E2E)),
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: const Color(0xFF00F5FF), size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Color(0xFF666677), fontSize: 12, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: statusColor.withOpacity(0.4)),
            ),
            child: Text(status, style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = const [
    DpiControllerPage(),
    SensitivityPage(),
    ScreenSizePage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0F),
        elevation: 0,
        title: Row(
          children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFF00F5FF), Color(0xFFFF006E)],
                ),
              ),
              child: const Icon(Icons.settings_input_component_rounded, size: 16, color: Colors.white),
            ),
            const SizedBox(width: 10),
            const Text('XyrooSensix', style: TextStyle(
              fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 1,
              color: Color(0xFF00F5FF),
            )),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF00FF88).withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF00FF88).withOpacity(0.4)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, color: Color(0xFF00FF88), size: 8),
                SizedBox(width: 6),
                Text('Shizuku', style: TextStyle(color: Color(0xFF00FF88), fontSize: 11, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: Color(0xFF1E1E2E))),
          color: Color(0xFF0D0D14),
        ),
        child: NavigationBar(
          backgroundColor: Colors.transparent,
          indicatorColor: const Color(0xFF00F5FF).withOpacity(0.15),
          selectedIndex: _currentIndex,
          onDestinationSelected: (i) => setState(() => _currentIndex = i),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.tune_rounded),
              selectedIcon: Icon(Icons.tune_rounded, color: Color(0xFF00F5FF)),
              label: 'DPI',
            ),
            NavigationDestination(
              icon: Icon(Icons.ads_click_rounded),
              selectedIcon: Icon(Icons.ads_click_rounded, color: Color(0xFF00F5FF)),
              label: 'Sens',
            ),
            NavigationDestination(
              icon: Icon(Icons.aspect_ratio_rounded),
              selectedIcon: Icon(Icons.aspect_ratio_rounded, color: Color(0xFF00F5FF)),
              label: 'Screen',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings_rounded),
              selectedIcon: Icon(Icons.settings_rounded, color: Color(0xFF00F5FF)),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }
}

// ─── DPI CONTROLLER PAGE ──────────────────────────────────────────────────────
class DpiControllerPage extends StatefulWidget {
  const DpiControllerPage({super.key});
  @override
  State<DpiControllerPage> createState() => _DpiControllerPageState();
}

class _DpiControllerPageState extends State<DpiControllerPage> {
  double _dpi = 400;
  String _currentDpi = '400';
  String _log = '';
  bool _isExecuting = false;
  final TextEditingController _customDpiCtrl = TextEditingController();

  final List<Map<String, dynamic>> _presets = [
    {'label': 'Low', 'dpi': 200, 'desc': 'Tampilan besar'},
    {'label': 'Normal', 'dpi': 320, 'desc': 'Default'},
    {'label': 'HD', 'dpi': 400, 'desc': 'Seimbang'},
    {'label': 'FHD', 'dpi': 480, 'desc': 'Tajam'},
    {'label': 'QHD', 'dpi': 560, 'desc': 'Ultra tajam'},
    {'label': 'UHD', 'dpi': 640, 'desc': 'Max density'},
  ];

  void _applyDpi(int dpi) {
    setState(() {
      _isExecuting = true;
      _log = 'Executing: wm density $dpi\n';
    });
    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() {
        _currentDpi = '$dpi';
        _log += 'Done: wm density $dpi\n[i] DPI applied successfully.';
        _isExecuting = false;
      });
    });
  }

  void _resetDpi() {
    setState(() {
      _isExecuting = true;
      _log = 'Executing: wm density reset\n';
    });
    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() {
        _currentDpi = 'Default';
        _log += 'Done: wm density reset\n[i] DPI reset to default.';
        _isExecuting = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Current DPI Card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color(0xFF00F5FF).withOpacity(0.1), const Color(0xFF7B2FFF).withOpacity(0.05)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF00F5FF).withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Current DPI', style: TextStyle(color: Color(0xFF888899), fontSize: 12, letterSpacing: 1)),
                    const SizedBox(height: 4),
                    Text(_currentDpi, style: const TextStyle(
                      fontSize: 48, fontWeight: FontWeight.w900, color: Color(0xFF00F5FF),
                    )),
                    const Text('wm density', style: TextStyle(color: Color(0xFF555566), fontSize: 12, fontFamily: 'monospace')),
                  ],
                ),
              ),
              Column(
                children: [
                  _isExecuting
                      ? const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: Color(0xFF00F5FF)))
                      : const Icon(Icons.check_circle_rounded, color: Color(0xFF00FF88), size: 28),
                  const SizedBox(height: 8),
                  Text(_isExecuting ? 'Applying...' : 'Ready',
                      style: TextStyle(color: _isExecuting ? const Color(0xFF00F5FF) : const Color(0xFF00FF88), fontSize: 11)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // Slider
        const _SectionLabel('Adjust DPI'),
        const SizedBox(height: 8),
        Row(
          children: [
            const Text('200', style: TextStyle(color: Color(0xFF555566), fontSize: 11)),
            Expanded(
              child: SliderTheme(
                data: SliderThemeData(
                  trackHeight: 4,
                  thumbColor: const Color(0xFF00F5FF),
                  activeTrackColor: const Color(0xFF00F5FF),
                  inactiveTrackColor: const Color(0xFF1E1E2E),
                  overlayColor: const Color(0xFF00F5FF).withOpacity(0.15),
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
                ),
                child: Slider(
                  value: _dpi,
                  min: 200,
                  max: 700,
                  divisions: 50,
                  onChanged: (v) => setState(() => _dpi = v),
                ),
              ),
            ),
            const Text('700', style: TextStyle(color: Color(0xFF555566), fontSize: 11)),
          ],
        ),
        Center(
          child: Text('${_dpi.toInt()} DPI', style: const TextStyle(
            color: Color(0xFF00F5FF), fontWeight: FontWeight.w700, fontSize: 16,
          )),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: () => _applyDpi(_dpi.toInt()),
                  icon: const Icon(Icons.play_arrow_rounded, size: 18),
                  label: const Text('Apply', style: TextStyle(fontWeight: FontWeight.w700)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00F5FF),
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              height: 48,
              child: OutlinedButton.icon(
                onPressed: _resetDpi,
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Reset'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF888899),
                  side: const BorderSide(color: Color(0xFF333344)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Presets
        const _SectionLabel('Quick Presets'),
        const SizedBox(height: 10),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          childAspectRatio: 1.5,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: _presets.map((p) => GestureDetector(
            onTap: () {
              setState(() => _dpi = (p['dpi'] as int).toDouble());
              _applyDpi(p['dpi'] as int);
            },
            child: Container(
              decoration: BoxDecoration(
                color: _dpi.toInt() == p['dpi'] ? const Color(0xFF00F5FF).withOpacity(0.15) : const Color(0xFF111118),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _dpi.toInt() == p['dpi'] ? const Color(0xFF00F5FF) : const Color(0xFF1E1E2E),
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(p['label'], style: TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 14,
                    color: _dpi.toInt() == p['dpi'] ? const Color(0xFF00F5FF) : Colors.white,
                  )),
                  Text('${p['dpi']}', style: const TextStyle(color: Color(0xFF555566), fontSize: 11)),
                ],
              ),
            ),
          )).toList(),
        ),
        const SizedBox(height: 20),

        // Custom DPI
        const _SectionLabel('Custom DPI'),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _customDpiCtrl,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  hintText: 'Enter DPI 200-1000',
                  hintStyle: const TextStyle(color: Color(0xFF444455)),
                  filled: true,
                  fillColor: const Color(0xFF111118),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF1E1E2E)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF1E1E2E)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF00F5FF)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  final val = int.tryParse(_customDpiCtrl.text);
                  if (val != null && val >= 200 && val <= 1000) {
                    setState(() => _dpi = val.toDouble());
                    _applyDpi(val);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7B2FFF),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Set', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Shell Log
        if (_log.isNotEmpty) ...[
          const _SectionLabel('Shell Log'),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF060610),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF1E1E2E)),
            ),
            child: Text(_log, style: const TextStyle(
              fontFamily: 'monospace', fontSize: 12, color: Color(0xFF00FF88), height: 1.6,
            )),
          ),
          const SizedBox(height: 16),
        ],
      ],
    );
  }
}

// ─── SENSITIVITY PAGE ─────────────────────────────────────────────────────────
class SensitivityPage extends StatefulWidget {
  const SensitivityPage({super.key});
  @override
  State<SensitivityPage> createState() => _SensitivityPageState();
}

class _SensitivityPageState extends State<SensitivityPage> {
  int _selectedGame = 0;
  double _general = 100, _redDot = 80, _scope2x = 60, _scope4x = 40, _sniperScope = 20;

  final List<Map<String, dynamic>> _games = [
    {'name': 'FREE FIRE', 'icon': Icons.local_fire_department_rounded, 'color': Color(0xFFFF6B00)},
    {'name': 'FREE FIRE MAX', 'icon': Icons.whatshot_rounded, 'color': Color(0xFFFF003D)},
    {'name': 'PUBG MOBILE', 'icon': Icons.sports_esports_rounded, 'color': Color(0xFFFFAA00)},
    {'name': 'MOBILE LEGENDS', 'icon': Icons.bolt_rounded, 'color': Color(0xFF00AAFF)},
  ];

  final List<Map<String, dynamic>> _presets = [
    {'label': 'Low Sens', 'general': 60.0, 'red': 50.0, 's2': 40.0, 's4': 30.0, 'sniper': 15.0},
    {'label': 'Medium', 'general': 90.0, 'red': 75.0, 's2': 60.0, 's4': 45.0, 'sniper': 20.0},
    {'label': 'High Sens', 'general': 120.0, 'red': 100.0, 's2': 80.0, 's4': 60.0, 'sniper': 30.0},
    {'label': 'Pro', 'general': 100.0, 'red': 85.0, 's2': 65.0, 's4': 50.0, 'sniper': 25.0},
  ];

  @override
  Widget build(BuildContext context) {
    final game = _games[_selectedGame];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Game selector
        const _SectionLabel('Select Game'),
        const SizedBox(height: 10),
        SizedBox(
          height: 50,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _games.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) {
              final g = _games[i];
              final sel = i == _selectedGame;
              return GestureDetector(
                onTap: () => setState(() => _selectedGame = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: sel ? (g['color'] as Color).withOpacity(0.2) : const Color(0xFF111118),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: sel ? g['color'] as Color : const Color(0xFF1E1E2E)),
                  ),
                  child: Row(
                    children: [
                      Icon(g['icon'] as IconData, size: 16, color: sel ? g['color'] as Color : const Color(0xFF555566)),
                      const SizedBox(width: 6),
                      Text(g['name'] as String, style: TextStyle(
                        color: sel ? g['color'] as Color : const Color(0xFF555566),
                        fontSize: 12, fontWeight: FontWeight.w700,
                      )),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 20),

        // Presets
        const _SectionLabel('Sensitivity Presets'),
        const SizedBox(height: 10),
        Row(
          children: _presets.map((p) => Expanded(
            child: GestureDetector(
              onTap: () => setState(() {
                _general = p['general']!;
                _redDot = p['red']!;
                _scope2x = p['s2']!;
                _scope4x = p['s4']!;
                _sniperScope = p['sniper']!;
              }),
              child: Container(
                margin: const EdgeInsets.only(right: 6),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF111118),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF1E1E2E)),
                ),
                child: Center(
                  child: Text(p['label']!, style: const TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFF888899),
                  )),
                ),
              ),
            ),
          )).toList(),
        ),
        const SizedBox(height: 20),

        // Sensitivity sliders
        _SensSlider(label: 'General', icon: Icons.open_with_rounded, value: _general, color: game['color'] as Color,
            onChanged: (v) => setState(() => _general = v)),
        _SensSlider(label: 'Red Dot', icon: Icons.adjust_rounded, value: _redDot, color: const Color(0xFFFF006E),
            onChanged: (v) => setState(() => _redDot = v)),
        _SensSlider(label: '2x Scope', icon: Icons.zoom_in_rounded, value: _scope2x, color: const Color(0xFF00AAFF),
            onChanged: (v) => setState(() => _scope2x = v)),
        _SensSlider(label: '4x Scope', icon: Icons.zoom_in_map_rounded, value: _scope4x, color: const Color(0xFF7B2FFF),
            onChanged: (v) => setState(() => _scope4x = v)),
        _SensSlider(label: 'Sniper', icon: Icons.my_location_rounded, value: _sniperScope, color: const Color(0xFFFFAA00),
            onChanged: (v) => setState(() => _sniperScope = v)),
        const SizedBox(height: 16),

        // Apply button
        SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton.icon(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Sensitivity applied for ${game['name']}!'),
                backgroundColor: const Color(0xFF111118),
                behavior: SnackBarBehavior.floating,
              ),
            ),
            icon: const Icon(Icons.check_rounded),
            label: const Text('Apply Sensitivity', style: TextStyle(fontWeight: FontWeight.w800)),
            style: ElevatedButton.styleFrom(
              backgroundColor: game['color'] as Color,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
      ],
    );
  }
}

class _SensSlider extends StatelessWidget {
  final String label;
  final IconData icon;
  final double value;
  final Color color;
  final ValueChanged<double> onChanged;
  const _SensSlider({required this.label, required this.icon, required this.value, required this.color, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF111118),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1E1E2E)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              const Spacer(),
              Text('${value.toInt()}', style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 16)),
            ],
          ),
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 3,
              thumbColor: color,
              activeTrackColor: color,
              inactiveTrackColor: const Color(0xFF1E1E2E),
              overlayColor: color.withOpacity(0.15),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
            ),
            child: Slider(value: value, min: 0, max: 200, onChanged: onChanged),
          ),
        ],
      ),
    );
  }
}

// ─── SCREEN SIZE PAGE ─────────────────────────────────────────────────────────
class ScreenSizePage extends StatefulWidget {
  const ScreenSizePage({super.key});
  @override
  State<ScreenSizePage> createState() => _ScreenSizePageState();
}

class _ScreenSizePageState extends State<ScreenSizePage> {
  final _wCtrl = TextEditingController(text: '1080');
  final _hCtrl = TextEditingController(text: '1920');
  String _log = '';
  bool _isExecuting = false;

  final List<Map<String, dynamic>> _resolutions = [
    {'label': '720p', 'w': 720, 'h': 1280},
    {'label': '1080p', 'w': 1080, 'h': 1920},
    {'label': '1440p', 'w': 1440, 'h': 2560},
    {'label': '4K', 'w': 2160, 'h': 3840},
    {'label': '720x1600', 'w': 720, 'h': 1600},
    {'label': '1080x2400', 'w': 1080, 'h': 2400},
  ];

  void _applySize(int w, int h) {
    setState(() {
      _isExecuting = true;
      _log = 'Executing: wm size ${w}x$h\n';
    });
    Future.delayed(const Duration(milliseconds: 900), () {
      setState(() {
        _log += 'Done: wm size ${w}x$h\n[i] Screen size applied.';
        _isExecuting = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Info card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFF006E).withOpacity(0.07),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFFF006E).withOpacity(0.3)),
          ),
          child: Row(
            children: [
              const Icon(Icons.info_outline_rounded, color: Color(0xFFFF006E), size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Mengubah resolusi layar menggunakan "wm size". Memerlukan Shizuku.',
                  style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12, height: 1.4),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('Resolution Presets'),
        const SizedBox(height: 10),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          childAspectRatio: 1.6,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          children: _resolutions.map((r) => GestureDetector(
            onTap: () {
              setState(() {
                _wCtrl.text = '${r['w']}';
                _hCtrl.text = '${r['h']}';
              });
              _applySize(r['w'] as int, r['h'] as int);
            },
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF111118),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF1E1E2E)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(r['label'] as String, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                  Text('${r['w']}×${r['h']}', style: const TextStyle(color: Color(0xFF555566), fontSize: 10)),
                ],
              ),
            ),
          )).toList(),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('Custom Resolution'),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _buildField('Width', _wCtrl),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Text('×', style: TextStyle(fontSize: 20, color: Color(0xFF555566))),
            ),
            Expanded(
              child: _buildField('Height', _hCtrl),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _isExecuting ? null : () {
                    final w = int.tryParse(_wCtrl.text);
                    final h = int.tryParse(_hCtrl.text);
                    if (w != null && h != null) _applySize(w, h);
                  },
                  icon: _isExecuting
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                      : const Icon(Icons.aspect_ratio_rounded, size: 18),
                  label: Text(_isExecuting ? 'Applying...' : 'Apply Size',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00F5FF),
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () => setState(() => _log = 'Executing: wm size reset\nDone: wm size reset'),
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Reset'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF888899),
                  side: const BorderSide(color: Color(0xFF333344)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ],
        ),
        if (_log.isNotEmpty) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF060610),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF1E1E2E)),
            ),
            child: Text(_log, style: const TextStyle(
              fontFamily: 'monospace', fontSize: 12, color: Color(0xFF00FF88), height: 1.6,
            )),
          ),
        ],
        const SizedBox(height: 20),
        // Overscan reset
        const _SectionLabel('Overscan'),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF111118),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF1E1E2E)),
          ),
          child: Row(
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Reset Overscan', style: TextStyle(fontWeight: FontWeight.w700)),
                    SizedBox(height: 4),
                    Text('wm overscan reset', style: TextStyle(color: Color(0xFF555566), fontSize: 12, fontFamily: 'monospace')),
                  ],
                ),
              ),
              ElevatedButton(
                onPressed: () => setState(() => _log = 'Executing: wm overscan reset\nDone: wm overscan reset'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7B2FFF),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('Run', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildField(String hint, TextEditingController ctrl) {
    return TextField(
      controller: ctrl,
      keyboardType: TextInputType.number,
      style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
      decoration: InputDecoration(
        labelText: hint,
        labelStyle: const TextStyle(color: Color(0xFF555566), fontSize: 12),
        filled: true,
        fillColor: const Color(0xFF111118),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF1E1E2E))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF1E1E2E))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF00F5FF))),
      ),
    );
  }
}

// ─── SETTINGS PAGE ────────────────────────────────────────────────────────────
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _floatingWindow = false;
  bool _autoApply = false;
  bool _hapticFeedback = true;
  bool _safeMode = true;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Profile card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color(0xFF7B2FFF).withOpacity(0.2), const Color(0xFF00F5FF).withOpacity(0.05)],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF7B2FFF).withOpacity(0.4)),
          ),
          child: Row(
            children: [
              Container(
                width: 54, height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [Color(0xFF00F5FF), Color(0xFF7B2FFF)]),
                ),
                child: const Center(child: Text('X', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
              ),
              const SizedBox(width: 16),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('XyrooSensix', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                  Text('v1.0.0 BETA', style: TextStyle(color: Color(0xFF888899), fontSize: 12)),
                  Text('DPI & Sensitivity Controller', style: TextStyle(color: Color(0xFF555566), fontSize: 11)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const _SectionLabel('App Settings'),
        const SizedBox(height: 10),
        _ToggleTile(
          icon: Icons.layers_rounded,
          iconColor: const Color(0xFF00F5FF),
          title: 'Floating Window',
          subtitle: 'Tampilkan shortcut di atas aplikasi lain',
          value: _floatingWindow,
          onChanged: (v) => setState(() => _floatingWindow = v),
        ),
        _ToggleTile(
          icon: Icons.auto_mode_rounded,
          iconColor: const Color(0xFF00FF88),
          title: 'Auto Apply on Launch',
          subtitle: 'Terapkan setting otomatis saat mulai',
          value: _autoApply,
          onChanged: (v) => setState(() => _autoApply = v),
        ),
        _ToggleTile(
          icon: Icons.vibration_rounded,
          iconColor: const Color(0xFFFFAA00),
          title: 'Haptic Feedback',
          subtitle: 'Getaran saat menerapkan perubahan',
          value: _hapticFeedback,
          onChanged: (v) => setState(() => _hapticFeedback = v),
        ),
        _ToggleTile(
          icon: Icons.security_rounded,
          iconColor: const Color(0xFFFF006E),
          title: 'Safe DPI Mode',
          subtitle: 'Batasi DPI ke rentang aman (200-700)',
          value: _safeMode,
          onChanged: (v) => setState(() => _safeMode = v),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('Shizuku'),
        const SizedBox(height: 10),
        _ActionTile(
          icon: Icons.security_rounded,
          iconColor: const Color(0xFF00F5FF),
          title: 'Shizuku Permission',
          subtitle: 'Grant izin untuk menjalankan shell',
          onTap: () {},
          trailing: const _Badge('Granted', Color(0xFF00FF88)),
        ),
        _ActionTile(
          icon: Icons.terminal_rounded,
          iconColor: const Color(0xFF7B2FFF),
          title: 'Open Shizuku',
          subtitle: 'Buka aplikasi Shizuku',
          onTap: () {},
        ),
        const SizedBox(height: 20),
        const _SectionLabel('Info'),
        const SizedBox(height: 10),
        _ActionTile(
          icon: Icons.update_rounded,
          iconColor: const Color(0xFFFFAA00),
          title: 'Check Update',
          subtitle: 'Cek versi terbaru XyrooSensix',
          onTap: () {},
        ),
        _ActionTile(
          icon: Icons.group_rounded,
          iconColor: const Color(0xFF00AAFF),
          title: 'Join Community',
          subtitle: 'Dapatkan update dan info terbaru',
          onTap: () {},
        ),
        const SizedBox(height: 32),
        Center(
          child: Text('XyrooSensix v1.0.0 BETA\nDPI & Sensitivity Controller',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF333344), fontSize: 11, height: 1.8)),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}

class _ToggleTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title, subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _ToggleTile({required this.icon, required this.iconColor, required this.title, required this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF111118),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1E1E2E)),
      ),
      child: ListTile(
        leading: Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: iconColor, size: 20),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(color: Color(0xFF555566), fontSize: 12)),
        trailing: Switch(
          value: value,
          onChanged: onChanged,
          activeColor: const Color(0xFF00F5FF),
          activeTrackColor: const Color(0xFF00F5FF).withOpacity(0.25),
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title, subtitle;
  final VoidCallback onTap;
  final Widget? trailing;
  const _ActionTile({required this.icon, required this.iconColor, required this.title, required this.subtitle, required this.onTap, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF111118),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1E1E2E)),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: iconColor, size: 20),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(color: Color(0xFF555566), fontSize: 12)),
        trailing: trailing ?? const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Color(0xFF444455)),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge(this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(text.toUpperCase(), style: const TextStyle(
      color: Color(0xFF555566), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5,
    ));
  }
}
